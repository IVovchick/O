const score = document.querySelector('.score'),
        start = document.querySelector('.start'),
        gameArea = document.querySelector('.gameArea'),
        car = document.createElement('div'),
        music = document.createElement('audio'); //Добавление музыки способ 1 работает
        //music = document.createElement('embed');   //Добавление музыки способ 2 не работает

/*
//Добавление музыки способ 2
music.setAttribute('src','./music/audio1.mp3');
music.setAttribute('type','audio/mp3');
music.classList.add('music');
*/

car.classList.add('car');
start.addEventListener('click', startGame);
document.addEventListener('keydown', startRun);
document.addEventListener('keyup', stopRun);

const keys = {
        'ArrowUp': false,
        'ArrowDown': false,
        'ArrowRight': false,
        'ArrowLeft': false
};

const setting = {
        start: false,
        score: 0,
        speed: 3,
        traffic: 3
};

function getQuantityElements(heightElement){ //floor for min; ceil for max
//        return (Math.floor(document.documentElement.clientHeight / heightElement) + 1);
 //       return (Math.floor(gameArea.offsetHeight / heightElement) + 1);
        return (Math.ceil(gameArea.offsetHeight / heightElement) + 1);

}



function startGame(){
        start.classList.add('hide');
        gameArea.innerHTML = '';

        for (let i=0; i < getQuantityElements(75); i++) {
                const line = document.createElement('div');
                line.classList.add('line');
                line.y = i * 75;
                line.style.top = line.y + 'px';
                
                line.style.left=(gameArea.offsetWidth-10)/2 + 'px';
                gameArea.appendChild(line);
        }

        for (let i = 0; i < getQuantityElements(100 * setting.traffic); i++){
                const enemy = document.createElement('div');

                let enemyImg = Math.floor(Math.random()*2)+1;
                //console.log(enemyImg);

                enemy.classList.add('enemy');

                enemy.y = -100 * setting.traffic * (i+1);
                enemy.style.top = enemy.y + 'px';
                
                enemy.style.left = Math.floor(Math.random()*(gameArea.offsetWidth-enemy.style.width)) + 'px';
                
                enemy.style.background = 'transparent url(./image/enemy'+enemyImg+'.png) center / cover no-repeat';
                
                //console.log(enemy.style.background);

                gameArea.appendChild(enemy); 
                
                //console.dir(enemy);
        }
        setting.score = 0;
        setting.start = true;
        gameArea.appendChild(car);
        
        car.style.top = 'auto';
        car.style.bottom = '10px';
        setting.y = car.offsetTop;

        setting.x = (gameArea.offsetWidth-car.offsetWidth)/2;
        car.style.left = setting.x + 'px';     
        
        //Добавление музыки способ 1       
        music.setAttribute('src','./music/audio1.mp3');
        music.setAttribute('autoplay',true);
        music.setAttribute('controls',true); //Добавляем на страницу, если нужно управление
        music.classList.add('music');   //Добавляем на страницу, если нужно управление
        gameArea.appendChild(music);    //Добавляем на страницу, если нужно управление
               
        //Добавление музыки способ 2  
        //gameArea.appendChild(music); не работаеь
       
        requestAnimationFrame(playGame);

        //setTimeout(function(){setting.start = false;}, 10000);
}

function playGame(){
        //console.log('P G');
        
        if (setting.start) {
                setting.score += setting.speed;
                score.style.top = 0;
                score.innerHTML = 'Score<br>' + setting.score;
                moveRoad();
                moveEnemy();
                if(keys.ArrowLeft && setting.x > 0) {
                        setting.x -= setting.speed;
                }
                if(keys.ArrowRight && setting.x < (gameArea.offsetWidth-car.offsetWidth)) {
                        setting.x += setting.speed;
                }
                if(keys.ArrowUp && setting.y >= 3) {
                        setting.y -= setting.speed;
                }
                if(keys.ArrowDown && setting.y < (gameArea.offsetHeight-car.offsetHeight)) {
                        setting.y += setting.speed;
                }
                car.style.left = setting.x + 'px';
                car.style.top = setting.y + 'px';
                requestAnimationFrame(playGame);
        } else {
                music.remove();
        }
}

function moveRoad(){
        let lines = document.querySelectorAll('.line');
        lines.forEach(function(item){
                item.y += setting.speed;
                if (item.y >= gameArea.offsetHeight) {
                        item.y = -75;
                }
                item.style.top = item.y +'px';
        })
}

function moveEnemy(){
        let enemy = document.querySelectorAll('.enemy');
        enemy.forEach(function(item){
                let carRect = car.getBoundingClientRect();
                let enemyRect = item.getBoundingClientRect();
                if(carRect.top <= enemyRect.bottom &&
                   carRect.right >= enemyRect.left &&
                   carRect.left <= enemyRect.right &&
                   carRect.bottom >= enemyRect.top){
                        setting.start = false;
                        console.warn('DTP!!!');
                        start.classList.remove('hide');
                        score.style.top = start.offsetHeight;
                        music.remove();
                }


                item.y += setting.speed /2;
                if(item.y >= gameArea.offsetHeight){
                        item.y = -100 * setting.traffic;
                        item.style.left = Math.floor(Math.random()*(gameArea.offsetWidth-item.offsetWidth)) + 'px';

                }
                item.style.top = item.y +'px';
        })
}

function startRun(event){
        event.preventDefault();
        //if(event.key in keys){ //Это проверяет не только в самом обёкте но во всей цепочке родителей       
        if(keys.hasOwnProperty(event.key)){ //Это проверяет только в самом обёкте и сооьветственно быстрее
                keys[event.key] = true;
        }
        //console.log(keys);
        
}

function stopRun(event){
        event.preventDefault();
        if(keys.hasOwnProperty(event.key)){
                keys[event.key] = false;
        }
}

 